﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Newtonsoft.Json;
using ZL.Infrastructure;
using System.Security.Cryptography;
using System.Text;

namespace ZL.Web.Controllers
{
    public class MPController : ApiController
    {
        // GET api/<controller>
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }
        /// <summary>
        /// 获取Openid
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult GetOpenid([FromBody]WechatLoginInfo loginfo)
        {
            string appid = ConfigurationManager.AppSettings["AppID"];
            string appsecret = ConfigurationManager.AppSettings["AppSecret"];
            WeChatAppDecrypt wcad = new WeChatAppDecrypt(appid, appsecret);
            var resultInfo = wcad.DecodeOpenIdAndSessionKey(new WechatLoginInfo() { code = loginfo.code });
            SqlParameter[] paras = new SqlParameter[]
                {
                new SqlParameter("@openid",resultInfo.openid),
                new SqlParameter("@sessionkey",resultInfo.session_key)
                // new SqlParameter("@openid","2"),
                //new SqlParameter("@sessionkey","3333")
                };
            string sql = @" exec AddUser @openid,@sessionkey";
            DbHelperSQL db = new DbHelperSQL();
            db.ExecuteSql(sql, paras);
            return Ok(resultInfo.openid);
        }

        /// <summary>
        /// 保存微信用户信息
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult SaveWechatUserInfo([FromBody]WechatUInfo user)
        {
            SqlParameter[] paras = new SqlParameter[]
                {
                new SqlParameter("@openid",user.Openid),
                new SqlParameter("@gender",user.Gender),
                new SqlParameter("@avatarUrl",user.AvatarUrl),
                new SqlParameter("@city",user.City),
                new SqlParameter("@country",user.Country),
                new SqlParameter("@language",user.Language),
                new SqlParameter("@province",user.Province),
                new SqlParameter("@nickname",user.NickName)
                };
            string sql = @"UPDATE [JM_WechatUserInfo]
                           SET [NickName] = @nickname
                              ,[AvatarUrl] =@avatarUrl
                              ,[Gender] = @gender
                              ,[Language] = @language
                              ,[Country] = @country
                              ,[Province] = @province
                              ,[City] = @city
                         WHERE openid=@openid";
            DbHelperSQL db = new DbHelperSQL();
            db.ExecuteSql(sql, paras);
            return Ok(true);
        }

        /// <summary>
        /// 登录
        /// </summary>
        /// <param name="loginfo"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult Login([FromBody]ShopLoginUserInfo loginfo)
        {
            ZLHttpRequet zlhttp = new ZLHttpRequet();
            string s = zlhttp.Post(ConfigurationManager.AppSettings["api"] + "/auth/login", JsonConvert.SerializeObject(loginfo));
            var info = JsonConvert.DeserializeObject<Root>(s);
            if (info != null && info.cellphone != null)
            {
                SqlParameter[] paras = new SqlParameter[]
                {
                new SqlParameter("@openid",loginfo.Openid),
                new SqlParameter("@cellphone",info.cellphone),
                new SqlParameter("@photo",info.photo),
                new SqlParameter("@userName",info.userName),
                new SqlParameter("@userId",info.userId),
                new SqlParameter("@formID",loginfo.FormID)
                };
                string sql = @"exec [AddShopUser] @openid,@cellphone,@photo,@userName,@userId,@formID,1";
                DbHelperSQL db = new DbHelperSQL();
                db.ExecuteSql(sql, paras);
                return Ok(true);
            }
            else if (info != null && info.message != null)
            {
                return Ok(info.message);
            }
            else
            {
                return Ok(false);
            }
        }

        /// <summary>
        /// 获取短信验证码
        /// </summary>
        /// <param name="loginfo"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult GetSms([FromBody]ShopUserInfo loginfo)
        {
            ZLHttpRequet zlhttp = new ZLHttpRequet();
            string s = zlhttp.Post(ConfigurationManager.AppSettings["api"] + "/sms/vcode", JsonConvert.SerializeObject(loginfo));
            var info = JsonConvert.DeserializeObject<Root>(s);
            if (info != null && info.result != null)
            {
                return Ok(true);
            }
            else if (info != null && info.message != null)
            {
                return Ok(info.message);
            }
            else
            {
                return Ok(false);
            }
        }

        /// <summary>
        /// 注册
        /// </summary>
        /// <param name="loginfo"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult Register([FromBody]ShopUserInfo loginfo)
        {
            ZLHttpRequet zlhttp = new ZLHttpRequet();
            string s = zlhttp.Post(ConfigurationManager.AppSettings["api"] + "/auth/register", JsonConvert.SerializeObject(loginfo));
            var info = JsonConvert.DeserializeObject<Root>(s);
            if (info != null && info.result != null)
            {
                SqlParameter[] paras = new SqlParameter[]
                {
                new SqlParameter("@openid",loginfo.Openid),
                new SqlParameter("@cellphone",info.cellphone),
                new SqlParameter("@photo",""),
                new SqlParameter("@userName",info.userName),
                new SqlParameter("@userId",info.storeUserId),
                new SqlParameter("@formID",loginfo.FormID)
                };
                string sql = @"exec [AddShopUser] @openid,@cellphone,@photo,@userName,@userId,@formID,1";
                DbHelperSQL db = new DbHelperSQL();
                db.ExecuteSql(sql, paras);
                return Ok(true);
            }
            else if (info != null && info.message != null)
            {
                return Ok(info.message);
            }
            else
            {
                return Ok(false);
            }
        }

        /// <summary>
        /// 剩余返现金额
        /// </summary>
        /// <param name="loginfo"></param>
        /// <returns></returns>
        [HttpGet]
        public IHttpActionResult GetTotalRecharge()
        {
            ZLHttpRequet zlhttp = new ZLHttpRequet();
            string s = zlhttp.Get(ConfigurationManager.AppSettings["api"] + "/auth/getTotalRecharge?key=sS5W8R7Ktt2bF7g4&startTime=2018-10-01 00:00:00&endTime=2018-10-10 00:00:00&activityId=6", "");
            var info = JsonConvert.DeserializeObject<Root>(s);
            if (info != null && info.rechargeAmout !=0)
            {
                //float all = info.RechargeCashbackActivity.cashbackAggregateLimit;
                float use =(6000000- info.rechargeAmout)/10000;
                return Ok(use);
            }
            else
            {
                return Ok(0);
            }
        }

        /// <summary>
        /// 拉取商城用户消费金额
        /// </summary>
        /// <param name="shopInfo"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult Getamount([FromBody]ShopLoginUserInfo shopInfo)
        {
            ZLHttpRequet zlhttp = new ZLHttpRequet();
            string s = zlhttp.Get(ConfigurationManager.AppSettings["api"] + "/rcActivity/shoppingRate?activityId=7&userId=" + shopInfo.UserName, "");
            var info = JsonConvert.DeserializeObject<Root>(s);
            if (info != null && info.data != null)
            {
                SqlParameter[] paras = new SqlParameter[]
                {
                new SqlParameter("@ShopInitRate",info.data.initRate),
                new SqlParameter("@ShopSpendingAmount",info.data.spendingAmount),
                new SqlParameter("@ShopUserID",shopInfo.UserName),
                };
                string sql = @" update[JM_ShopUserInfo] set[ShopInitRate] =@ShopInitRate,[ShopSpendingAmount]=@ShopSpendingAmount  where[ShopUserID]=@ShopUserID";
                DbHelperSQL db = new DbHelperSQL();
                db.ExecuteSql(sql, paras);
               
                //float all = info.RechargeCashbackActivity.cashbackAggregateLimit;
               
                return Ok(info.data);
            }
            else
            {
                return Ok(false);
            }
        }

        /// <summary>
        /// 同步返现倍数
        /// </summary>
        /// <param name="shopInfo"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult Rate([FromBody]Rote shopInfo)
        {

           // MD5Encrypt32('');
            ZLHttpRequet zlhttp = new ZLHttpRequet();
            shopInfo.sign = MD5Encrypt32(shopInfo.activityId+"|"+ shopInfo.userId + "|"+ shopInfo.openId + "|"+ shopInfo.lastRate + "|kei3jw");
            string s = zlhttp.Post(ConfigurationManager.AppSettings["api"] + "/rcActivity/rate", JsonConvert.SerializeObject(shopInfo));
            var info = JsonConvert.DeserializeObject<Root>(s);
            if (info != null && info.data != null)
            {
                //float all = info.RechargeCashbackActivity.cashbackAggregateLimit;
                return Ok(true);
            }
            else
            {
                return Ok(false);
            }
        }

        /// <summary>
        /// 获取有多少位好友帮助
        /// </summary>
        /// <param name="wu"></param>
        /// <returns></returns>
        [HttpPost]
        public IHttpActionResult GetHelp([FromBody]WechatUInfo wu)
        {

            // MD5Encrypt32('');
            //ZLHttpRequet zlhttp = new ZLHttpRequet();
            //shopInfo.sign = MD5Encrypt32(shopInfo.activityId + "|" + shopInfo.userId + "|" + shopInfo.openId + "|" + shopInfo.lastRate + "|kei3jw");
            //string s = zlhttp.Post(ConfigurationManager.AppSettings["api"] + "/rcActivity/rate", JsonConvert.SerializeObject(shopInfo));
            //var info = JsonConvert.DeserializeObject<Root>(s);
            //if (info != null && info.data != null)
            //{
            //    //float all = info.RechargeCashbackActivity.cashbackAggregateLimit;
            //    return Ok(true);
            //}
            //else
            //{
            //    return Ok(false);
            //}
            SqlParameter[] paras = new SqlParameter[]
                {
                new SqlParameter("@Openid",wu.Openid), };
            string sql = @" select w.[AvatarUrl] from JM_Invitationinfo h left join[JM_WechatUserInfo] w on h.fopenid=w.Openid where h.openid=@Openid";
            DbHelperSQL db = new DbHelperSQL();
            var data=db.Query(sql, paras);
            List<string> listHead = new List<string>();
            if (data.Tables[0].Rows.Count>0)
            {
                for (int i = 0; i < data.Tables[0].Rows.Count; i++)
                {
                    listHead.Add(data.Tables[0].Rows[0][i]+"");
                }
                return Ok(listHead);
            }
            else
            {
                return Ok("");
            }

            
        }

        public static string MD5Encrypt32(string password)
        {
            string cl = password;
            string pwd = "";
            MD5 md5 = MD5.Create(); //实例化一个md5对像
                                    // 加密后是一个字节类型的数组，这里要注意编码UTF8/Unicode等的选择　
            byte[] s = md5.ComputeHash(Encoding.UTF8.GetBytes(cl));
            // 通过使用循环，将字节类型的数组转换为字符串，此字符串是常规字符格式化所得
            for (int i = 0; i < s.Length; i++)
            {
                // 将得到的字符串使用十六进制类型格式。格式后的字符是小写的字母，如果使用大写（X）则格式后的字符是大写字符 
                pwd = pwd + s[i].ToString("X");
            }
            return pwd.ToLower();
        }

        // GET api/<controller>/5
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<controller>
        public void Post([FromBody]WechatLoginInfo loginfo)
        {

            //new WechatLoginInfo()
            //{
            //    code = "011Y4LA02peroZ0H91y02YUpA02Y4LAg",
            //    encryptedData = "WXDO/llRYLhs24UpBeP6a+V4fZqYhUTJt/kKidYyp3TbGsE3wE7yuk3seQjZPV+vK/r0VG7vzu5FrV6c2h8u7KE6r2vn/GqAURunXO42hd14cDvJw7AMecTRCjf3r8xLba5JNU3xTNXcONRm98LTP3MN6TRvH69WqIrufZGoMh3nAd54mmpiFAlHPK8yUVsSD+nHA57roV70LOLGDT8dtyAXApbVdwcLlya1JMwBfcXd6U0QFFa+Q77rhJVFfCzUQGw7rAjijfT5lVnnBhSEkBQXWPjzRdiQZ7aD7/m9Fb9vXJpXlDH48HV9PsPcuW1R5Yl68ZedEUaX3raSsDZbojSK0csDq6oOF+hoISPlIPo7axp6gsvJ3fC1QLVYHHv/DqY4XaM9yWeEeih+C+8GinzJOzNso9SN5WGfHJbEocGqskiUHNrPGDMGU+A1B8i3296Q3Xw/+kuZHEj7zjqDerPVdgkdNLwxPMV444BnviM=",
            //    iv = "eBXlugT85RWW9s9q3ur4jg==",
            //    rawData = "{'nickName':'王博士','gender':1,'language':'zh_CN','city':'Liaocheng','province':'Shandong','country':'China','avatarUrl':'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKcthg7CBtDdBSrpX5RDyrLxicctz8V2LXgIJXCzdpicAJ9r1kRWRYcLtiallWkEI73wzEiaJicOImW9uw/132'}",
            //    signature = "ad8eee39a418dc83f62ba950ad9d340ae3e8581a",
            //});


            //var d = wcad.Decrypt(new WechatLoginInfo()
            //{
            //    code = "011Y4LA02peroZ0H91y02YUpA02Y4LAg",
            //    encryptedData = "WXDO/llRYLhs24UpBeP6a+V4fZqYhUTJt/kKidYyp3TbGsE3wE7yuk3seQjZPV+vK/r0VG7vzu5FrV6c2h8u7KE6r2vn/GqAURunXO42hd14cDvJw7AMecTRCjf3r8xLba5JNU3xTNXcONRm98LTP3MN6TRvH69WqIrufZGoMh3nAd54mmpiFAlHPK8yUVsSD+nHA57roV70LOLGDT8dtyAXApbVdwcLlya1JMwBfcXd6U0QFFa+Q77rhJVFfCzUQGw7rAjijfT5lVnnBhSEkBQXWPjzRdiQZ7aD7/m9Fb9vXJpXlDH48HV9PsPcuW1R5Yl68ZedEUaX3raSsDZbojSK0csDq6oOF+hoISPlIPo7axp6gsvJ3fC1QLVYHHv/DqY4XaM9yWeEeih+C+8GinzJOzNso9SN5WGfHJbEocGqskiUHNrPGDMGU+A1B8i3296Q3Xw/+kuZHEj7zjqDerPVdgkdNLwxPMV444BnviM=",
            //    iv = "eBXlugT85RWW9s9q3ur4jg==",
            //    rawData = "{'nickName':'王博士','gender':1,'language':'zh_CN','city':'Liaocheng','province':'Shandong','country':'China','avatarUrl':'https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKcthg7CBtDdBSrpX5RDyrLxicctz8V2LXgIJXCzdpicAJ9r1kRWRYcLtiallWkEI73wzEiaJicOImW9uw/132'}",
            //    signature = "ad8eee39a418dc83f62ba950ad9d340ae3e8581a",
            //});
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }

        //private bool SaveUserInfo()
        //{

        //}
    }
    public class User
    {
        public string name { get; set; }
        public string age { get; set; }
    }
    /// <summary>
    /// 微信中的用户信息和sessionkey
    /// </summary>
    public class WechatUInfo
    {
        public string Openid { get; set; }
        public string SessionKey { get; set; }
        public string NickName { get; set; }
        public string AvatarUrl { get; set; }
        public string Gender { get; set; }
        public string Language { get; set; }
        public string Country { get; set; }
        public string Province { get; set; }
        public string City { get; set; }
        public string CreateTime { get; set; }
        public string UpdateTime { get; set; }
    }
    /// <summary>
    /// 商城用户信息
    /// </summary>
    public class ShopUserInfo
    {
        public string Cellphone { get; set; }
        public string Password { get; set; }
        public string Smscode { get; set; }
        public string Rand { get; set; }
        public string Captcha { get; set; }
        public string FormID { get; set; }
        public string ValidateType { get; set; }
        public string Openid { get; set; }

    }
    public class ShopLoginUserInfo
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string FormID { get; set; }
        public string Openid { get; set; }
    }
    public class ErrorsItem
    {
        /// <summary>
        /// 用户名或密码错误
        /// </summary>
        public string message { get; set; }
        /// <summary>
        /// [Forbidden] - 服务器拒绝执行该请求
        /// </summary>
        public string reason { get; set; }
    }
    public class RechargeCashbackActivity
    {
        /// <summary>
        /// 
        /// </summary>
        public string activityId { get; set; }
        /// <summary>
        /// 10.01充值活动
        /// </summary>
        public string activityName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string activityStatus { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public float cashbackAggregateLimit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string createTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string createUserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string createUserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string deleted { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string displayOrder { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string endTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string isCashbackLimit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string isRechargeLimit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string lastUpdate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string maxRate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string rechargeAggregateLimit { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string rechargeCount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string rechargeItems { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string startTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string updateTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string updateUserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string updateUserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string version { get; set; }
    }

    public class Data
    {
        /// <summary>
        /// 
        /// </summary>
        public double initRate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string spendingAmount { get; set; }
    }
    public class Root
    {
        /// <summary>
        /// 
        /// </summary>
        public int code { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public List<ErrorsItem> errors { get; set; }
        /// <summary>
        /// 用户名或密码错误
        /// </summary>
        public string message { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string cellphone { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string photo { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string userName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string userId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string token { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string result { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string cashAccount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string cityCode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string createTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string createUserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string createUserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string deleted { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string displayOrder { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string gender { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string growthValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string lastUpdate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string leverName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string password { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string passwordPay { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string passwordSalt { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string pointAccount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string presentAccount { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string provinceId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string provinceName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string registSource { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string storeId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string storeUserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string updateTime { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string updateUserId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string updateUserName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string userLevelId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string userStatus { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string version { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string vipcode { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public RechargeCashbackActivity RechargeCashbackActivity { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public float rechargeAmout { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public Data data { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lastRate { get; set; }
    }
    public class Rote
    {
        /// <summary>
        /// 
        /// </summary>
        public int activityId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string userId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string openId { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public double lastRate { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string sign { get; set; }
    }
}